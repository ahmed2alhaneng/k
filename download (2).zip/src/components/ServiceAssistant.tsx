
"use client";

import { useState } from "react";
import { aiPoweredServiceAssistant, AiPoweredServiceAssistantOutput } from "@/ai/flows/ai-powered-service-assistant-flow";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Sparkles, Loader2, Wrench, ShieldCheck } from "lucide-react";

export function ServiceAssistant() {
  const [issue, setIssue] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AiPoweredServiceAssistantOutput | null>(null);

  async function handleSubmit() {
    if (!issue.trim()) return;
    setLoading(true);
    try {
      const res = await aiPoweredServiceAssistant({ issueDescription: issue });
      setResult(res);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-4xl mx-auto py-12 px-4" id="ai-assistant">
      <Card className="border-primary/20 shadow-xl overflow-hidden">
        <CardHeader className="bg-primary/5 pb-8">
          <div className="flex items-center gap-2 mb-2 text-primary font-bold">
            <Sparkles className="w-5 h-5" />
            <span className="font-headline text-lg">المساعد الذكي لكلاسك فون</span>
          </div>
          <CardTitle className="font-headline text-3xl mb-2 text-foreground">شخّص مشكلة هاتفك فوراً</CardTitle>
          <CardDescription className="text-muted-foreground text-lg">
            صف المشكلة التي تواجهها، وسيقوم نظامنا المدعوم بالذكاء الاصطناعي بتقديم تشخيص أولي.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-8">
          <div className="space-y-6">
            <Textarea
              placeholder="مثال: الشاشة مكسورة ولا تستجيب للمس، أو الهاتف لا يشحن..."
              className="min-h-[120px] text-lg bg-background/50 border-primary/20 focus:border-accent"
              value={issue}
              onChange={(e) => setIssue(e.target.value)}
            />
            <Button 
              size="lg" 
              className="w-full bg-accent hover:bg-accent/90 text-white font-bold h-14 text-xl"
              onClick={handleSubmit}
              disabled={loading || !issue}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-6 w-6 animate-spin" />
                  جاري التحليل...
                </>
              ) : (
                "اطلب التشخيص الآن"
              )}
            </Button>

            {result && (
              <div className="mt-8 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="p-6 bg-secondary/30 rounded-xl border border-primary/10">
                  <h4 className="font-headline text-xl font-bold mb-3 flex items-center gap-2 text-primary">
                    <Wrench className="w-5 h-5" />
                    التشخيص المقترح:
                  </h4>
                  <p className="text-lg leading-relaxed">{result.diagnosis}</p>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  {result.suggestions.map((s, i) => (
                    <Card key={i} className="bg-background border-accent/20">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg flex items-center gap-2">
                          <ShieldCheck className="w-4 h-4 text-accent" />
                          {s.service}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground">{s.description}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                <div className="p-4 bg-accent/10 rounded-lg border border-accent/20 text-center">
                  <p className="text-accent font-bold text-lg">
                    السعر التقديري: {result.priceRange}
                  </p>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
