
"use client";

import { useState, useEffect } from "react";
import { generateReferralInsights, ReferralInsightsOutput } from "@/ai/flows/ai-generated-referral-insights";
import { Button } from "@/components/ui/button";
import { Search, Info, Loader2, Target, Sparkles, Activity } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

export function ReferralTracker() {
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [insights, setInsights] = useState<ReferralInsightsOutput | null>(null);

  const getSource = () => {
    if (typeof window === "undefined") return "direct";
    const ref = document.referrer;
    if (ref.includes("facebook.com")) return "فيسبوك (Facebook)";
    if (ref.includes("google.com")) return "جوجل (Google Search)";
    if (ref.includes("instagram.com")) return "إنستغرام (Instagram)";
    if (ref.includes("t.me")) return "تليجرام (Telegram)";
    return "زيارة مباشرة أو مصدر غير معروف";
  };

  const handleFetchInsights = async () => {
    setLoading(true);
    setIsOpen(true);
    try {
      const source = getSource();
      const res = await generateReferralInsights({ referralData: [source] });
      setInsights(res);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="fixed bottom-8 right-8 z-50 flex flex-col items-center gap-2 group">
        <div className="absolute -top-12 bg-primary text-background px-3 py-1 rounded-full text-xs font-bold opacity-0 group-hover:opacity-100 transition-opacity shadow-lg">
          عدسة الزوار
        </div>
        <Button
          onClick={handleFetchInsights}
          size="icon"
          className="h-16 w-16 rounded-full bg-primary hover:bg-primary/90 shadow-[0_0_30px_rgba(191,155,48,0.4)] relative flex items-center justify-center transition-transform active:scale-90"
        >
          <div className="absolute inset-0 rounded-full border-4 border-primary/20 animate-ping" />
          <Target className="h-8 w-8 text-background relative z-10" />
          <Activity className="absolute bottom-1 right-1 h-4 w-4 text-accent animate-pulse" />
        </Button>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-[450px] bg-background border-primary/30 shadow-2xl backdrop-blur-xl">
          <DialogHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <Sparkles className="w-8 h-8 text-primary animate-pulse" />
            </div>
            <DialogTitle className="font-headline text-3xl text-primary font-bold">عدسة زوار كلاسك فون</DialogTitle>
            <DialogDescription className="text-lg text-muted-foreground mt-2">
              تحليل ذكي لمصدر زيارتك واقتراحات مخصصة.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-8">
            {loading ? (
              <div className="flex flex-col items-center justify-center space-y-6">
                <Loader2 className="h-14 w-14 animate-spin text-primary" />
                <p className="text-primary font-bold animate-pulse text-lg">جاري مسح المصدر بالذكاء الاصطناعي...</p>
              </div>
            ) : insights ? (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="p-6 bg-secondary/30 rounded-[2rem] border border-primary/10 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-20 h-20 bg-primary/5 rounded-full blur-2xl" />
                  <div className="flex items-start gap-4">
                    <Info className="h-7 w-7 text-primary shrink-0 mt-1" />
                    <p className="text-lg leading-relaxed text-foreground italic font-medium">
                      "{insights.summary}"
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground uppercase tracking-widest">
                  <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  تحليل نشط الآن
                </div>

                <Button className="w-full h-14 rounded-2xl bg-primary hover:bg-primary/90 text-background font-bold text-lg" onClick={() => setIsOpen(false)}>
                  فهمت، شكراً
                </Button>
              </div>
            ) : null}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
