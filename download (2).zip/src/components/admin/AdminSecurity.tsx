
'use client';

import { useState } from 'react';
import { useAuth, useFirestore, useDoc, useMemoFirebase, useUser } from '@/firebase';
import { doc, setDoc, deleteDoc } from 'firebase/firestore';
import { updatePassword, updateEmail, reauthenticateWithCredential, EmailAuthProvider } from 'firebase/auth';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Lock, ShieldAlert, Save, RotateCcw, Loader2, KeyRound, User } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function AdminSecurity() {
  const auth = useAuth();
  const db = useFirestore();
  const { user } = useUser();
  const { toast } = useToast();

  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    currentPassword: '',
    newUsername: '',
    newPassword: '',
    confirmPassword: ''
  });

  const configRef = useMemoFirebase(() => doc(db, 'admin_config', 'settings'), [db]);
  const { data: config } = useDoc(configRef);

  const handleUpdateSecurity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !user.email) return;

    if (formData.newPassword !== formData.confirmPassword) {
      toast({ variant: "destructive", title: "خطأ", description: "كلمات المرور الجديدة غير متطابقة." });
      return;
    }

    setLoading(true);
    try {
      // إعادة المصادقة للتأكد من هوية المستخدم قبل تغيير الحساسيات
      const credential = EmailAuthProvider.credential(user.email, formData.currentPassword);
      await reauthenticateWithCredential(user, credential);

      // تحديث البريد الإلكتروني إذا تغير اسم المستخدم
      if (formData.newUsername) {
        const newEmail = `${formData.newUsername.trim().toLowerCase()}@classic-mobile.com`;
        await updateEmail(user, newEmail);
        // حفظ اسم المستخدم الجديد في الإعدادات
        await setDoc(configRef, { 
          customUsername: formData.newUsername.trim().toLowerCase(),
          isConfigured: true 
        }, { merge: true });
        
        // تحديث سجل الصلاحيات
        const roleRef = doc(db, 'roles_admin', user.uid);
        await setDoc(roleRef, { username: formData.newUsername.trim().toLowerCase() }, { merge: true });
      }

      // تحديث كلمة المرور
      if (formData.newPassword) {
        await updatePassword(user, formData.newPassword);
      }

      toast({ title: "تم تحديث الأمان", description: "تم تغيير بيانات الدخول بنجاح." });
      setFormData({ currentPassword: '', newUsername: '', newPassword: '', confirmPassword: '' });
    } catch (error: any) {
      console.error(error);
      toast({ 
        variant: "destructive", 
        title: "فشل التحديث", 
        description: "تأكد من صحة كلمة المرور الحالية." 
      });
    } finally {
      setLoading(false);
    }
  };

  const handleResetToDefaults = async () => {
    if (!confirm('هل أنت متأكد من العودة لإعدادات المصنع؟ سيتم إلغاء اسم المستخدم المخصص.')) return;
    
    setLoading(true);
    try {
      // حذف الإعدادات المخصصة من Firestore
      await deleteDoc(configRef);
      
      // ملاحظة: كلمة المرور في Firebase Auth لا يمكن "تصفيرها" برمجياً دون معرفة القديمة،
      // لكن حذف الإعدادات سيعيد اسم المستخدم الافتراضي 'ahmed_1990st' عند محاولة الدخول القادمة.
      
      toast({ title: "تم تصفير الإعدادات", description: "عاد اسم المستخدم للافتراضي. يرجى تذكر كلمة مرورك الحالية." });
    } catch (error) {
      toast({ variant: "destructive", title: "خطأ", description: "فشل تصفير الإعدادات." });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <Card className="border-destructive/20 shadow-2xl bg-secondary/10">
        <CardHeader className="bg-destructive/5 border-b border-destructive/10">
          <div className="flex items-center gap-2 text-destructive">
            <Lock className="w-6 h-6" />
            <CardTitle className="font-headline text-2xl">إدارة أمان النظام</CardTitle>
          </div>
          <CardDescription>قم بتغيير بيانات الدخول الخاصة بلوحة التحكم.</CardDescription>
        </CardHeader>
        <CardContent className="pt-8 space-y-6">
          <form onSubmit={handleUpdateSecurity} className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase text-muted-foreground flex items-center gap-2">
                  <KeyRound className="w-3 h-3" /> كلمة المرور الحالية (مطلوب للتأكيد)
                </label>
                <Input 
                  type="password" 
                  value={formData.currentPassword} 
                  onChange={e => setFormData({...formData, currentPassword: e.target.value})}
                  required
                  className="bg-background/50 border-primary/20"
                />
              </div>

              <div className="h-px bg-primary/10 my-4" />

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase text-muted-foreground flex items-center gap-2">
                  <User className="w-3 h-3" /> اسم مستخدم جديد (اختياري)
                </label>
                <Input 
                  placeholder="مثلاً: admin_classic"
                  value={formData.newUsername} 
                  onChange={e => setFormData({...formData, newUsername: e.target.value})}
                  className="bg-background/50 border-primary/20"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase text-muted-foreground">كلمة مرور جديدة</label>
                  <Input 
                    type="password" 
                    value={formData.newPassword} 
                    onChange={e => setFormData({...formData, newPassword: e.target.value})}
                    className="bg-background/50 border-primary/20"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase text-muted-foreground">تأكيد كلمة المرور</label>
                  <Input 
                    type="password" 
                    value={formData.confirmPassword} 
                    onChange={e => setFormData({...formData, confirmPassword: e.target.value})}
                    className="bg-background/50 border-primary/20"
                  />
                </div>
              </div>
            </div>

            <Button type="submit" disabled={loading} className="w-full h-14 bg-primary text-background font-bold text-lg hover:scale-[1.01] transition-all">
              {loading ? <Loader2 className="animate-spin" /> : <Save className="w-5 h-5 ml-2" />}
              حفظ وتطبيق إعدادات الأمان
            </Button>
          </form>

          <div className="pt-6 border-t border-primary/10">
            <div className="flex items-center gap-3 p-4 bg-destructive/5 rounded-2xl border border-destructive/10">
              <ShieldAlert className="w-8 h-8 text-destructive" />
              <div className="flex-1">
                <p className="text-sm font-bold">منطقة الخطر</p>
                <p className="text-xs text-muted-foreground">يمكنك استعادة اسم المستخدم الأصلي (ahmed_1990st) في حال النسيان.</p>
              </div>
              <Button onClick={handleResetToDefaults} variant="outline" className="border-destructive text-destructive hover:bg-destructive hover:text-white">
                <RotateCcw className="w-4 h-4 ml-2" />
                استعادة الافتراضي
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
