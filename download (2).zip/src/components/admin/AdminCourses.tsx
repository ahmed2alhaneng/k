
'use client';

import { useState } from 'react';
import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, doc } from 'firebase/firestore';
import { setDocumentNonBlocking, deleteDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Trash2, Edit2, Check, X, Upload, Loader2, GraduationCap, DollarSign, Clock, MapPin, Phone, Send } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';

export function AdminCourses() {
  const db = useFirestore();
  const coursesQuery = useMemoFirebase(() => collection(db, 'courses'), [db]);
  const { data: courses } = useCollection(coursesQuery);
  const { toast } = useToast();

  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    discountPrice: '',
    durationHours: '',
    location: 'بعقوبة - حي المعلمين',
    contactNumber: '',
    telegramUrl: '',
    locationUrl: '',
    imageUrl: ''
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 1024 * 1024) {
      toast({ variant: "destructive", title: "حجم الصورة كبير", description: "يرجى اختيار صورة أصغر من 1 ميجابايت." });
      return;
    }

    setIsUploading(true);
    const reader = new FileReader();
    reader.onloadend = () => {
      setFormData({ ...formData, imageUrl: reader.result as string });
      setIsUploading(false);
    };
    reader.readAsDataURL(file);
  };

  const handleSave = (id?: string) => {
    if (!formData.title || !formData.price) {
      toast({ variant: "destructive", title: "بيانات ناقصة", description: "يرجى كتابة عنوان الدورة وسعرها." });
      return;
    }

    const courseId = id || `course-${Date.now()}`;
    const docRef = doc(db, 'courses', courseId);
    
    setDocumentNonBlocking(docRef, {
      id: courseId,
      ...formData
    }, { merge: true });

    toast({ title: "تم الحفظ", description: "تم تحديث بيانات الدورة بنجاح." });
    resetForm();
  };

  const handleDelete = (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذه الدورة؟')) return;
    deleteDocumentNonBlocking(doc(db, 'courses', id));
    toast({ variant: "destructive", title: "تم الحذف", description: "تم حذف الدورة التدريبية." });
  };

  const resetForm = () => {
    setFormData({ 
      title: '', description: '', price: '', discountPrice: '', 
      durationHours: '', location: 'بعقوبة - حي المعلمين', 
      contactNumber: '', telegramUrl: '', locationUrl: '', imageUrl: '' 
    });
    setIsAdding(false);
    setEditingId(null);
  };

  const startEdit = (course: any) => {
    setFormData({ ...course });
    setEditingId(course.id);
    setIsAdding(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold font-headline">إدارة الدورات التدريبية</h2>
          <p className="text-muted-foreground text-sm">قم بإضافة عروض دورات الصيانة والتدريب المهني.</p>
        </div>
        {!isAdding && !editingId && (
          <Button onClick={() => setIsAdding(true)} className="bg-primary text-background font-bold shadow-lg">
            <Plus className="w-4 h-4 ml-2" />
            إضافة دورة جديدة
          </Button>
        )}
      </div>

      {(isAdding || editingId) && (
        <Card className="border-primary/40 bg-secondary/20 backdrop-blur-md shadow-2xl">
          <CardHeader>
            <CardTitle className="text-primary flex items-center gap-2">
              <GraduationCap className="w-5 h-5" />
              {editingId ? 'تعديل بيانات الدورة' : 'إنشاء دورة تدريبية جديدة'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase">عنوان الدورة</label>
                  <Input placeholder="مثلاً: دورة صيانة الهواتف المتقدمة" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} className="bg-background/50" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-muted-foreground uppercase">السعر الأصلي</label>
                    <Input placeholder="مثلاً: 200,000" value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} className="bg-background/50" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-muted-foreground uppercase">سعر الخصم (اختياري)</label>
                    <Input placeholder="مثلاً: 150,000" value={formData.discountPrice} onChange={e => setFormData({...formData, discountPrice: e.target.value})} className="bg-background/50" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-muted-foreground uppercase">عدد الساعات</label>
                    <Input placeholder="مثلاً: 40 ساعة" value={formData.durationHours} onChange={e => setFormData({...formData, durationHours: e.target.value})} className="bg-background/50" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-muted-foreground uppercase">رقم التواصل</label>
                    <Input placeholder="077XXXXXXXX" value={formData.contactNumber} onChange={e => setFormData({...formData, contactNumber: e.target.value})} className="bg-background/50" />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase">رابط التليجرام أو الخريطة</label>
                  <Input placeholder="https://t.me/..." value={formData.telegramUrl} onChange={e => setFormData({...formData, telegramUrl: e.target.value})} className="bg-background/50" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase">صورة الدورة</label>
                  <div className="relative aspect-video bg-background/50 rounded-2xl border-2 border-dashed border-primary/20 flex flex-col items-center justify-center overflow-hidden">
                    {formData.imageUrl ? (
                      <Image src={formData.imageUrl} alt="Preview" fill className="object-cover" />
                    ) : (
                      <div className="text-center p-2 opacity-40">
                        {isUploading ? <Loader2 className="animate-spin mx-auto" /> : <Upload className="w-8 h-8 mx-auto mb-2" />}
                        <p className="text-xs">اضغط للتحميل من الجهاز</p>
                      </div>
                    )}
                    <input type="file" accept="image/*" className="absolute inset-0 opacity-0 cursor-pointer" onChange={handleFileChange} />
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-muted-foreground uppercase">وصف الدورة (ماذا سيتعلم الطالب؟)</label>
              <Textarea placeholder="اكتب تفاصيل المنهج الدراسي..." value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="bg-background/50 min-h-[100px]" />
            </div>

            <div className="flex gap-4 pt-4 border-t border-primary/10">
              <Button onClick={() => handleSave(editingId || undefined)} className="flex-1 bg-green-600 hover:bg-green-700 h-14 font-bold">
                <Check className="w-4 h-4 ml-2" /> حفظ بيانات الدورة
              </Button>
              <Button onClick={resetForm} variant="outline" className="flex-1 h-14">
                <X className="w-4 h-4 ml-2" /> إلغاء
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses?.map((course) => (
          <Card key={course.id} className="bg-secondary/10 border-primary/10 overflow-hidden flex flex-col">
            <div className="relative h-48 w-full bg-background">
              {course.imageUrl && <Image src={course.imageUrl} alt={course.title} fill className="object-cover opacity-80" />}
              <div className="absolute top-2 right-2 bg-primary text-background font-bold px-3 py-1 rounded-full text-sm">
                {course.discountPrice ? `خصم: ${course.discountPrice}` : course.price}
              </div>
            </div>
            <CardContent className="p-6 flex-1 flex flex-col">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-bold text-primary font-headline">{course.title}</h3>
                <div className="flex gap-1">
                  <Button size="icon" variant="ghost" className="h-8 w-8 text-blue-400" onClick={() => startEdit(course)}>
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" onClick={() => handleDelete(course.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <div className="space-y-2 text-sm text-muted-foreground mb-4">
                <div className="flex items-center gap-2"><Clock className="w-3 h-3 text-primary" /> {course.durationHours}</div>
                <div className="flex items-center gap-2"><Phone className="w-3 h-3 text-primary" /> {course.contactNumber}</div>
              </div>
              <p className="text-xs text-muted-foreground line-clamp-2">{course.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
