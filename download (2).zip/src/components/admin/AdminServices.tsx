'use client';

import { useState } from 'react';
import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, doc } from 'firebase/firestore';
import { setDocumentNonBlocking, deleteDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, Edit2, Check, X, Monitor, Zap, ShieldCheck, Cpu, Smartphone, Wrench, Settings, Link as LinkIcon, Image as ImageIcon, Upload, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';

export function AdminServices() {
  const db = useFirestore();
  const servicesQuery = useMemoFirebase(() => collection(db, 'services'), [db]);
  const { data: services } = useCollection(servicesQuery);
  const { toast } = useToast();

  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    iconName: 'Wrench',
    imageUrl: ''
  });

  const icons = [
    { name: 'Monitor', icon: <Monitor className="w-4 h-4" /> },
    { name: 'Zap', icon: <Zap className="w-4 h-4" /> },
    { name: 'ShieldCheck', icon: <ShieldCheck className="w-4 h-4" /> },
    { name: 'Cpu', icon: <Cpu className="w-4 h-4" /> },
    { name: 'Smartphone', icon: <Smartphone className="w-4 h-4" /> },
    { name: 'Wrench', icon: <Wrench className="w-4 h-4" /> },
    { name: 'Settings', icon: <Settings className="w-4 h-4" /> },
    { name: 'LinkIcon', icon: <LinkIcon className="w-4 h-4" /> }
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 1024 * 1024) { // 1MB limit for Firestore doc size safety
      toast({ variant: "destructive", title: "حجم الصورة كبير", description: "يرجى اختيار صورة أصغر من 1 ميجابايت." });
      return;
    }

    setIsUploading(true);
    const reader = new FileReader();
    reader.onloadend = () => {
      setFormData({ ...formData, imageUrl: reader.result as string });
      setIsUploading(false);
      toast({ title: "تم تجهيز الصورة", description: "الصورة جاهزة للحفظ." });
    };
    reader.readAsDataURL(file);
  };

  const handleSave = (id?: string) => {
    if (!formData.name || !formData.description) {
      toast({ variant: "destructive", title: "بيانات ناقصة", description: "يرجى كتابة اسم الخدمة ووصفها." });
      return;
    }

    const serviceId = id || `service-${Date.now()}`;
    const docRef = doc(db, 'services', serviceId);
    
    setDocumentNonBlocking(docRef, {
      id: serviceId,
      ...formData
    }, { merge: true });

    toast({ title: "تم الحفظ", description: "تم تحديث بيانات الخدمة بنجاح." });
    resetForm();
  };

  const handleDelete = (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذه الخدمة؟')) return;
    deleteDocumentNonBlocking(doc(db, 'services', id));
    toast({ variant: "destructive", title: "تم الحذف", description: "تم حذف الخدمة." });
  };

  const resetForm = () => {
    setFormData({ name: '', description: '', iconName: 'Wrench', imageUrl: '' });
    setIsAdding(false);
    setEditingId(null);
  };

  const startEdit = (service: any) => {
    setFormData({
      name: service.name,
      description: service.description,
      iconName: service.iconName || 'Wrench',
      imageUrl: service.imageUrl || ''
    });
    setEditingId(service.id);
    setIsAdding(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold font-headline">إدارة الخدمات الملكية</h2>
          <p className="text-muted-foreground text-sm">أضف، عدل أو احذف الخدمات التي تظهر للزبائن.</p>
        </div>
        {!isAdding && !editingId && (
          <Button onClick={() => setIsAdding(true)} className="bg-primary text-background font-bold shadow-lg hover:scale-105 transition-all">
            <Plus className="w-4 h-4 ml-2" />
            إضافة خدمة جديدة
          </Button>
        )}
      </div>

      {(isAdding || editingId) && (
        <Card className="border-primary/40 bg-secondary/20 backdrop-blur-md shadow-2xl overflow-hidden">
          <CardHeader>
            <CardTitle className="text-primary flex items-center gap-2">
              <Settings className="w-5 h-5" />
              {editingId ? 'تعديل بيانات الخدمة' : 'إنشاء خدمة جديدة'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase">اسم الخدمة</label>
                  <Input 
                    placeholder="مثلاً: تبديل شاشة ايفون اصلية" 
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="bg-background/50 border-primary/20"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase">تحميل صورة من الجهاز</label>
                  <div className="flex items-center gap-4">
                    <Button 
                      variant="outline" 
                      className="w-full h-12 border-dashed border-primary/30 bg-primary/5 hover:bg-primary/10 relative"
                      disabled={isUploading}
                    >
                      {isUploading ? <Loader2 className="animate-spin" /> : <Upload className="w-5 h-5 ml-2" />}
                      {formData.imageUrl ? 'تغيير الصورة المرفوعة' : 'اختر صورة من جهازك'}
                      <input 
                        type="file" 
                        accept="image/*" 
                        className="absolute inset-0 opacity-0 cursor-pointer" 
                        onChange={handleFileChange}
                      />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase">الأيقونة (تستخدم في حال عدم وجود صورة)</label>
                  <Select value={formData.iconName} onValueChange={(val) => setFormData({...formData, iconName: val})}>
                    <SelectTrigger className="bg-background/50 border-primary/20">
                      <SelectValue placeholder="اختر أيقونة" />
                    </SelectTrigger>
                    <SelectContent>
                      {icons.map((item) => (
                        <SelectItem key={item.name} value={item.name}>
                          <div className="flex items-center gap-2">
                            {item.icon}
                            <span>{item.name}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex flex-col items-center justify-center p-4 bg-background/30 rounded-2xl border border-primary/10 min-h-[200px]">
                {formData.imageUrl ? (
                  <div className="relative w-full h-full min-h-[180px]">
                    <Image 
                      src={formData.imageUrl} 
                      alt="Preview" 
                      fill 
                      className="object-contain rounded-lg"
                    />
                    <Button 
                      size="icon" 
                      variant="destructive" 
                      className="absolute top-0 right-0 rounded-full h-8 w-8"
                      onClick={() => setFormData({...formData, imageUrl: ''})}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="text-center text-muted-foreground">
                    <ImageIcon className="w-12 h-12 mx-auto mb-2 opacity-20" />
                    <p className="text-xs">معاينة الصورة ستظهر هنا</p>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-muted-foreground uppercase">وصف الخدمة</label>
              <Textarea 
                placeholder="اشرح للعميل ماذا تشمل الخدمة والضمان المقدم..." 
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                className="bg-background/50 min-h-[100px] border-primary/20"
              />
            </div>

            <div className="flex gap-4 pt-4 border-t border-primary/10">
              <Button onClick={() => handleSave(editingId || undefined)} className="flex-1 bg-green-600 hover:bg-green-700 h-14 font-bold shadow-lg">
                <Check className="w-4 h-4 ml-2" />
                تأكيد وحفظ التغييرات
              </Button>
              <Button onClick={resetForm} variant="outline" className="flex-1 h-14 border-primary/20">
                <X className="w-4 h-4 ml-2" />
                إلغاء
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {services?.map((service) => (
          <Card key={service.id} className="bg-secondary/10 border-primary/10 hover:border-primary/30 transition-all group relative overflow-hidden flex flex-col">
            <div className="relative h-48 w-full bg-background/50">
              {service.imageUrl ? (
                <Image 
                  src={service.imageUrl} 
                  alt={service.name} 
                  fill 
                  className="object-cover opacity-80 group-hover:opacity-100 transition-opacity"
                />
              ) : (
                <div className="absolute inset-0 flex items-center justify-center opacity-20">
                   {icons.find(i => i.name === service.iconName)?.icon || <Wrench className="w-12 h-12" />}
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
            </div>
            
            <CardContent className="p-6 relative z-10 flex-1 flex flex-col">
              <div className="flex justify-between items-start mb-4">
                <div className="p-3 bg-primary/10 rounded-xl">
                  {icons.find(i => i.name === service.iconName)?.icon || <Wrench className="w-5 h-5 text-primary" />}
                </div>
                <div className="flex gap-1">
                  <Button size="icon" variant="ghost" className="h-8 w-8 hover:bg-blue-500/20" title="تعديل" onClick={() => startEdit(service)}>
                    <Edit2 className="w-4 h-4 text-blue-400" />
                  </Button>
                  <Button size="icon" variant="ghost" className="h-8 w-8 hover:bg-destructive/20" title="حذف" onClick={() => handleDelete(service.id)}>
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>
              </div>
              <h3 className="text-xl font-bold mb-2 text-primary font-headline">{service.name}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3 flex-1">{service.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {(!services || services.length === 0) && !isAdding && (
        <div className="py-20 text-center border-2 border-dashed border-primary/20 rounded-3xl">
          <p className="text-muted-foreground font-headline text-xl">لا توجد خدمات حالياً، ابدأ بإضافة خدمتك الأولى!</p>
        </div>
      )}
    </div>
  );
}
