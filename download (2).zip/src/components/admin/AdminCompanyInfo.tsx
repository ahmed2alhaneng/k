
'use client';

import { useState, useEffect } from 'react';
import { useFirestore, useDoc, useMemoFirebase } from '@/firebase';
import { doc } from 'firebase/firestore';
import { setDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Save, Loader2, MessageCircle, MapPin, Clock, Globe } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function AdminCompanyInfo() {
  const db = useFirestore();
  const infoRef = useMemoFirebase(() => doc(db, 'businessProfile', 'classic_mobile'), [db]);
  const { data: info, isLoading } = useDoc(infoRef);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: 'كلاسك فون',
    address: 'بعقوبة - حي المعلمين',
    whatsappNumber: '9647700583840',
    telegramUrl: '',
    operatingHours: '9:00 صباحاً - 9:00 مساءً'
  });

  useEffect(() => {
    if (info) {
      setFormData({
        name: info.name || '',
        address: info.address || '',
        whatsappNumber: info.whatsappNumber || '',
        telegramUrl: info.telegramUrl || '',
        operatingHours: info.operatingHours || ''
      });
    }
  }, [info]);

  const handleSave = () => {
    setDocumentNonBlocking(infoRef, {
      id: 'classic_mobile',
      ...formData
    }, { merge: true });
    toast({ title: "تم التحديث", description: "تم حفظ معلومات المركز بنجاح." });
  };

  if (isLoading) return <div className="flex justify-center p-20"><Loader2 className="animate-spin h-12 w-12 text-primary" /></div>;

  return (
    <div className="grid grid-cols-1 gap-8">
      <Card className="bg-secondary/10 border-primary/20 shadow-2xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="text-primary w-5 h-5" />
            بيانات الهوية والتواصل
          </CardTitle>
          <CardDescription>تحكم في كيفية ظهور المركز للجمهور.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-muted-foreground uppercase">اسم المركز</label>
              <Input value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="bg-background/50 border-primary/10" />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1">
                <MessageCircle className="w-3 h-3" /> رقم الواتساب
              </label>
              <Input dir="ltr" value={formData.whatsappNumber} onChange={(e) => setFormData({...formData, whatsappNumber: e.target.value})} className="bg-background/50 border-primary/10" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1">
                <MapPin className="w-3 h-3" /> العنوان الفعلي
              </label>
              <Input value={formData.address} onChange={(e) => setFormData({...formData, address: e.target.value})} className="bg-background/50 border-primary/10" />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-1">
                <Clock className="w-3 h-3" /> ساعات العمل
              </label>
              <Input value={formData.operatingHours} onChange={(e) => setFormData({...formData, operatingHours: e.target.value})} className="bg-background/50 border-primary/10" />
            </div>
          </div>
          <Button onClick={handleSave} className="w-full bg-primary text-background font-bold h-12 mt-4 hover:scale-[1.02] transition-transform">
            <Save className="w-5 h-5 ml-2" />
            حفظ كافة التغييرات
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
