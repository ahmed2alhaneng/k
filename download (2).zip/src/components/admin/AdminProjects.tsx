
'use client';

import { useState } from 'react';
import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, doc } from 'firebase/firestore';
import { setDocumentNonBlocking, deleteDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Trash2, Calendar, Check, X, LayoutGrid, Upload, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';

export function AdminProjects() {
  const db = useFirestore();
  const projectsQuery = useMemoFirebase(() => collection(db, 'repairShowcases'), [db]);
  const { data: projects } = useCollection(projectsQuery);
  const { toast } = useToast();

  const [isAdding, setIsAdding] = useState(false);
  const [isUploadingBefore, setIsUploadingBefore] = useState(false);
  const [isUploadingAfter, setIsUploadingAfter] = useState(false);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    beforePhotoUrl: '',
    afterPhotoUrl: '',
    dateCompleted: new Date().toISOString().split('T')[0]
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'before' | 'after') => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 1024 * 1024) { 
      toast({ variant: "destructive", title: "حجم الصورة كبير", description: "يرجى اختيار صورة أصغر من 1 ميجابايت." });
      return;
    }

    if (type === 'before') setIsUploadingBefore(true);
    else setIsUploadingAfter(true);

    const reader = new FileReader();
    reader.onloadend = () => {
      if (type === 'before') {
        setFormData({ ...formData, beforePhotoUrl: reader.result as string });
        setIsUploadingBefore(false);
      } else {
        setFormData({ ...formData, afterPhotoUrl: reader.result as string });
        setIsUploadingAfter(false);
      }
      toast({ title: "تم الرفع", description: `تم تجهيز صورة "${type === 'before' ? 'قبل' : 'بعد'}"` });
    };
    reader.readAsDataURL(file);
  };

  const handleSave = () => {
    if (!formData.title) {
      toast({ variant: "destructive", title: "بيانات ناقصة", description: "يرجى ملء العنوان على الأقل." });
      return;
    }

    const id = `showcase-${Date.now()}`;
    const docRef = doc(db, 'repairShowcases', id);
    
    setDocumentNonBlocking(docRef, {
      id,
      ...formData
    }, { merge: true });

    toast({ title: "تمت الإضافة", description: "تمت إضافة المشروع للمعرض بنجاح." });
    resetForm();
  };

  const handleDelete = (id: string) => {
    if (!confirm('هل تريد حذف هذا المشروع من المعرض؟')) return;
    deleteDocumentNonBlocking(doc(db, 'repairShowcases', id));
    toast({ variant: "destructive", title: "تم الحذف", description: "تم إزالة المشروع." });
  };

  const resetForm = () => {
    setFormData({ title: '', description: '', beforePhotoUrl: '', afterPhotoUrl: '', dateCompleted: new Date().toISOString().split('T')[0] });
    setIsAdding(false);
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold font-headline">معرض الإنجازات</h2>
          <p className="text-muted-foreground text-sm">اعرض مهاراتك من خلال صور قبل وبعد.</p>
        </div>
        {!isAdding && (
          <Button onClick={() => setIsAdding(true)} className="bg-primary text-background font-bold shadow-lg">
            <Plus className="w-4 h-4 ml-2" />
            إضافة إنجاز جديد
          </Button>
        )}
      </div>

      {isAdding && (
        <Card className="border-primary/40 bg-secondary/20 backdrop-blur-md shadow-2xl">
          <CardHeader>
            <CardTitle>إضافة مشروع صيانة جديد</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase">عنوان المشروع</label>
                  <Input placeholder="مثلاً: ايفون 14 برو - كسر شاشة" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} className="bg-background/50" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase">تاريخ الإنجاز</label>
                  <Input type="date" value={formData.dateCompleted} onChange={e => setFormData({...formData, dateCompleted: e.target.value})} className="bg-background/50" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase text-center block">صورة (قبل)</label>
                  <div className="relative aspect-square bg-background/50 rounded-2xl border-2 border-dashed border-primary/20 flex flex-col items-center justify-center overflow-hidden">
                    {formData.beforePhotoUrl ? (
                      <Image src={formData.beforePhotoUrl} alt="Before" fill className="object-cover" />
                    ) : (
                      <div className="text-center p-2">
                        {isUploadingBefore ? <Loader2 className="animate-spin text-primary" /> : <Upload className="w-6 h-6 mx-auto mb-1 opacity-20" />}
                        <p className="text-[10px]">رفع صورة قبل</p>
                      </div>
                    )}
                    <input type="file" accept="image/*" className="absolute inset-0 opacity-0 cursor-pointer" onChange={(e) => handleFileChange(e, 'before')} />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase text-center block">صورة (بعد)</label>
                  <div className="relative aspect-square bg-background/50 rounded-2xl border-2 border-dashed border-primary/20 flex flex-col items-center justify-center overflow-hidden">
                    {formData.afterPhotoUrl ? (
                      <Image src={formData.afterPhotoUrl} alt="After" fill className="object-cover" />
                    ) : (
                      <div className="text-center p-2">
                        {isUploadingAfter ? <Loader2 className="animate-spin text-primary" /> : <Upload className="w-6 h-6 mx-auto mb-1 opacity-20" />}
                        <p className="text-[10px]">رفع صورة بعد</p>
                      </div>
                    )}
                    <input type="file" accept="image/*" className="absolute inset-0 opacity-0 cursor-pointer" onChange={(e) => handleFileChange(e, 'after')} />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex gap-4 pt-4 border-t border-primary/10">
              <Button onClick={handleSave} className="flex-1 bg-green-600 hover:bg-green-700 h-14 font-bold">
                <Check className="w-4 h-4 ml-2" /> حفظ المشروع
              </Button>
              <Button onClick={resetForm} variant="outline" className="flex-1 h-14">
                <X className="w-4 h-4 ml-2" /> إلغاء
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {projects?.map((project) => (
          <Card key={project.id} className="bg-secondary/10 border-primary/10 overflow-hidden">
            <div className="grid grid-cols-2 h-56 relative bg-background">
              <div className="relative border-l border-primary/20">
                {project.beforePhotoUrl && <Image src={project.beforePhotoUrl} alt="Before" fill className="object-cover" />}
                <div className="absolute top-2 right-2 bg-black/80 text-white text-[10px] px-2 py-1 rounded-full font-bold">قبل</div>
              </div>
              <div className="relative">
                {project.afterPhotoUrl && <Image src={project.afterPhotoUrl} alt="After" fill className="object-cover" />}
                <div className="absolute top-2 right-2 bg-primary text-background text-[10px] font-bold px-2 py-1 rounded-full">بعد</div>
              </div>
            </div>
            <CardContent className="p-5 flex justify-between items-center bg-secondary/5">
              <div className="space-y-1">
                <h4 className="font-bold text-primary text-lg font-headline">{project.title}</h4>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Calendar className="w-3 h-3" />
                  <span>{project.dateCompleted}</span>
                </div>
              </div>
              <Button size="icon" variant="ghost" className="hover:bg-destructive/20 text-destructive" onClick={() => handleDelete(project.id)}>
                <Trash2 className="w-5 h-5" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
