'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useUser, useFirestore, useDoc, useMemoFirebase, useAuth, useCollection } from '@/firebase';
import { doc, collection } from 'firebase/firestore';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  LayoutDashboard, 
  Settings, 
  Wrench, 
  Image as ImageIcon, 
  LogOut,
  Loader2,
  ShieldAlert,
  Lock,
  Home,
  GraduationCap,
  TrendingUp,
  Clock
} from 'lucide-react';
import { AdminServices } from '@/components/admin/AdminServices';
import { AdminCompanyInfo } from '@/components/admin/AdminCompanyInfo';
import { AdminProjects } from '@/components/admin/AdminProjects';
import { AdminSecurity } from '@/components/admin/AdminSecurity';
import { AdminCourses } from '@/components/admin/AdminCourses';

export default function AdminDashboard() {
  const { user, isUserLoading } = useUser();
  const auth = useAuth();
  const db = useFirestore();
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  const [currentTime, setCurrentTime] = useState<string>('');

  useEffect(() => {
    setMounted(true);
    setCurrentTime(new Date().toLocaleTimeString('ar-IQ'));
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString('ar-IQ'));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const servicesQuery = useMemoFirebase(() => {
    if (!db) return null;
    return collection(db, 'services');
  }, [db]);
  const { data: services } = useCollection(servicesQuery);
  
  const projectsQuery = useMemoFirebase(() => {
    if (!db) return null;
    return collection(db, 'repairShowcases');
  }, [db]);
  const { data: projects } = useCollection(projectsQuery);

  const coursesQuery = useMemoFirebase(() => {
    if (!db) return null;
    return collection(db, 'courses');
  }, [db]);
  const { data: courses } = useCollection(coursesQuery);

  const adminDocRef = useMemoFirebase(() => {
    if (!db || !user) return null;
    return doc(db, 'roles_admin', user.uid);
  }, [db, user]);

  const { data: adminRole, isLoading: isAdminLoading } = useDoc(adminDocRef);

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push('/admin/login');
    }
  }, [user, isUserLoading, router]);

  const handleLogout = async () => {
    if (!auth) return;
    await auth.signOut();
    router.push('/');
  };

  if (!mounted || isUserLoading || isAdminLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-12 h-12 animate-spin text-primary" />
      </div>
    );
  }

  if (!adminRole) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4 text-center">
        <ShieldAlert className="w-20 h-20 text-destructive mb-6" />
        <h1 className="text-3xl font-bold mb-2 font-headline">عذراً، لا تملك صلاحيات الوصول</h1>
        <p className="text-muted-foreground mb-8">يجب أن يكون حسابك مسجلاً كمسؤول في النظام.</p>
        <Button onClick={() => router.push('/')} variant="outline">العودة للرئيسية</Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-primary/20 bg-secondary/10 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <LayoutDashboard className="text-background w-6 h-6" />
              </div>
              <h1 className="font-headline text-lg md:text-2xl font-bold truncate">لوحة التحكم الملكية</h1>
            </div>
            <div className="h-8 w-px bg-primary/20" />
            <Button 
              variant="ghost" 
              className="flex items-center gap-2 text-primary hover:bg-primary/10 px-2 md:px-4"
              onClick={() => router.push('/')}
            >
              <Home className="w-4 h-4" />
              <span className="hidden sm:inline">معاينة الموقع</span>
            </Button>
          </div>
          <div className="flex items-center gap-2 md:gap-4">
            <div className="hidden lg:flex flex-col items-end">
              <span className="text-sm font-bold text-primary">{adminRole.username || 'المسؤول'}</span>
              <span className="text-[10px] text-muted-foreground">صلاحيات كاملة</span>
            </div>
            <Button variant="ghost" size="icon" onClick={handleLogout} className="text-destructive hover:bg-destructive/10">
              <LogOut className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          <Card className="bg-secondary/20 border-primary/10">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center text-blue-500">
                <Wrench className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase">الخدمات</p>
                <p className="text-2xl font-bold">{services?.length || 0}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-secondary/20 border-primary/10">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center text-green-500">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase">الدورات</p>
                <p className="text-2xl font-bold">{courses?.length || 0}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-secondary/20 border-primary/10">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center text-purple-500">
                <TrendingUp className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase">الحالة</p>
                <p className="text-lg font-bold text-green-500">نشط الآن</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-secondary/20 border-primary/10">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 bg-orange-500/20 rounded-xl flex items-center justify-center text-orange-500">
                <Clock className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase">بغداد</p>
                <p className="text-lg font-bold">{currentTime || '--:--:--'}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="services" className="space-y-8">
          <TabsList className="bg-secondary/30 p-1 rounded-xl h-auto flex flex-wrap gap-2 border border-primary/10 justify-start mb-6">
            <TabsTrigger value="services" className="data-[state=active]:bg-primary data-[state=active]:text-background rounded-lg px-6 py-3 font-bold">
              <Wrench className="w-4 h-4 ml-2" />
              الخدمات
            </TabsTrigger>
            <TabsTrigger value="courses" className="data-[state=active]:bg-primary data-[state=active]:text-background rounded-lg px-6 py-3 font-bold">
              <GraduationCap className="w-4 h-4 ml-2" />
              الدورات
            </TabsTrigger>
            <TabsTrigger value="gallery" className="data-[state=active]:bg-primary data-[state=active]:text-background rounded-lg px-6 py-3 font-bold">
              <ImageIcon className="w-4 h-4 ml-2" />
              قبل وبعد
            </TabsTrigger>
            <TabsTrigger value="info" className="data-[state=active]:bg-primary data-[state=active]:text-background rounded-lg px-6 py-3 font-bold">
              <Settings className="w-4 h-4 ml-2" />
              الهوية
            </TabsTrigger>
            <TabsTrigger value="security" className="data-[state=active]:bg-destructive data-[state=active]:text-white rounded-lg px-6 py-3 font-bold">
              <Lock className="w-4 h-4 ml-2" />
              الأمان
            </TabsTrigger>
          </TabsList>

          <TabsContent value="services" className="animate-in fade-in duration-500">
            <AdminServices />
          </TabsContent>

          <TabsContent value="courses" className="animate-in fade-in duration-500">
            <AdminCourses />
          </TabsContent>

          <TabsContent value="info" className="animate-in fade-in duration-500">
            <AdminCompanyInfo />
          </TabsContent>

          <TabsContent value="gallery" className="animate-in fade-in duration-500">
            <AdminProjects />
          </TabsContent>

          <TabsContent value="security" className="animate-in fade-in duration-500">
            <AdminSecurity />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
