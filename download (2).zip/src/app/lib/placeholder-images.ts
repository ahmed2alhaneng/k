
import data from './placeholder-images.json';

export type ImagePlaceholder = {
  id: string;
  description: string;
  imageUrl: string;
  imageHint: string;
};

/**
 * Safely exports the placeholder images array.
 * Fallback to an empty array if the JSON data is missing or malformed.
 */
export const PlaceHolderImages: ImagePlaceholder[] = data?.placeholderImages || [];
