export const firebaseConfig = {
  "projectId": "studio-7081280671-ff170",
  "appId": "1:516342657941:web:ec939764dcd255c2b17c9c",
  "apiKey": "AIzaSyD-pOWMXua5gRwG-wZ56V0qLhKmpGafZks",
  "authDomain": "studio-7081280671-ff170.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "516342657941"
};
