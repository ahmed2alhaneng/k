'use server';
/**
 * @fileOverview A Genkit flow for providing AI-powered service suggestions for phone repair.
 *
 * - aiPoweredServiceAssistant - A function that handles the AI-powered service suggestion process.
 * - AiPoweredServiceAssistantInput - The input type for the aiPoweredServiceAssistant function.
 * - AiPoweredServiceAssistantOutput - The return type for the aiPoweredServiceAssistant function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AiPoweredServiceAssistantInputSchema = z.object({
  issueDescription: z
    .string()
    .describe('وصف المشكلة التي تواجه الهاتف.'),
});
export type AiPoweredServiceAssistantInput = z.infer<
  typeof AiPoweredServiceAssistantInputSchema
>;

const AiPoweredServiceAssistantOutputSchema = z.object({
  diagnosis: z
    .string()
    .describe('التشخيص المحتمل للمشكلة بناءً على الوصف.'),
  suggestions: z
    .array(
      z.object({
        service: z.string().describe('اسم الخدمة المقترحة.'),
        description: z
          .string()
          .describe('وصف موجز للخدمة المقترحة وكيف يمكنها حل المشكلة.'),
      })
    )
    .describe('قائمة باقتراحات خدمة الإصلاح.'),
  priceRange: z
    .string()
    .describe(
      'نطاق السعر التقديري للإصلاح (على سبيل المثال: 50-100 دينار عراقي، أو يتطلب فحص).'
    ),
});
export type AiPoweredServiceAssistantOutput = z.infer<
  typeof AiPoweredServiceAssistantOutputSchema
>;

export async function aiPoweredServiceAssistant(
  input: AiPoweredServiceAssistantInput
): Promise<AiPoweredServiceAssistantOutput> {
  return aiPoweredServiceAssistantFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiPoweredServiceAssistantPrompt',
  input: {schema: AiPoweredServiceAssistantInputSchema},
  output: {schema: AiPoweredServiceAssistantOutputSchema},
  prompt: `أنت خبير في صيانة الهواتف لمركز "كلاسك فون". مهمتك هي تقديم تشخيصات محتملة واقتراحات لخدمات الإصلاح ونطاقات أسعار تقديرية بناءً على وصف العميل لمشكلة هاتفه.\n\nالخدمات التي يقدمها "كلاسك فون" هي: تبديل الشاشات، تبديل ايسيات الشحن، تبديل الكنكترات، تخطي الايكلود، سوفت وير، وتبديل جميع قطع الغيار الأصلية/الوكالة فقط. نحن نضمن استخدام قطع غيار وكالة فقط.\n\nوصف مشكلة العميل: {{{issueDescription}}}\n\nبناءً على وصف المشكلة، يرجى تقديم:\n1.  تشخيص محتمل للمشكلة.\n2.  اقتراحات لخدمات الإصلاح من قائمة الخدمات المتاحة لدينا.\n3.  نطاق سعر تقديري للإصلاح. إذا كان من الصعب تحديد نطاق سعر دقيق بدون فحص، اذكر أنه يتطلب فحص.`,
});

const aiPoweredServiceAssistantFlow = ai.defineFlow(
  {
    name: 'aiPoweredServiceAssistantFlow',
    inputSchema: AiPoweredServiceAssistantInputSchema,
    outputSchema: AiPoweredServiceAssistantOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
