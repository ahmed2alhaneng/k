'use server';
/**
 * @fileOverview This file implements a Genkit flow to analyze visitor referral data and generate concise, actionable summaries of traffic sources.
 *
 * - generateReferralInsights - A function that triggers the AI analysis of referral data.
 * - ReferralInsightsInput - The input type for the generateReferralInsights function.
 * - ReferralInsightsOutput - The return type for the generateReferralInsights function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const ReferralInsightsInputSchema = z.object({
  referralData: z.array(z.string()).describe('An array of strings, where each string represents a visitor referral source (e.g., "facebook.com", "google.com", "direct").'),
});
export type ReferralInsightsInput = z.infer<typeof ReferralInsightsInputSchema>;

const ReferralInsightsOutputSchema = z.object({
  summary: z.string().describe('A concise, actionable summary of the analyzed traffic sources, highlighting key platforms and insights.'),
});
export type ReferralInsightsOutput = z.infer<typeof ReferralInsightsOutputSchema>;

export async function generateReferralInsights(input: ReferralInsightsInput): Promise<ReferralInsightsOutput> {
  return aiGeneratedReferralInsightsFlow(input);
}

const referralInsightsPrompt = ai.definePrompt({
  name: 'referralInsightsPrompt',
  input: { schema: ReferralInsightsInputSchema },
  output: { schema: ReferralInsightsOutputSchema },
  prompt: `You are an AI assistant specialized in marketing and traffic analysis. Your task is to analyze the provided visitor referral data and generate a concise, actionable summary of the traffic sources.
Identify the main platforms, quantify their presence if possible, and provide insights into potential customer engagement. Highlight which platforms are most effective and suggest actionable steps to leverage or improve traffic from each source.

Referral Data:
{{#each referralData}}- {{{this}}}
{{/each}}`,
});

const aiGeneratedReferralInsightsFlow = ai.defineFlow(
  {
    name: 'aiGeneratedReferralInsightsFlow',
    inputSchema: ReferralInsightsInputSchema,
    outputSchema: ReferralInsightsOutputSchema,
  },
  async (input) => {
    const { output } = await referralInsightsPrompt(input);
    return output!;
  }
);
