import { config } from 'dotenv';
config();

import '@/ai/flows/ai-generated-referral-insights.ts';
import '@/ai/flows/ai-powered-service-assistant-flow.ts';