'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth, useFirestore, useDoc, useMemoFirebase } from '@/firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Smartphone, Lock, User, Sparkles, ArrowRight, Loader2, ShieldAlert } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function AdminLogin() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const auth = useAuth();
  const db = useFirestore();
  const router = useRouter();
  const { toast } = useToast();

  const configRef = useMemoFirebase(() => {
    if (!db) return null;
    return doc(db, 'admin_config', 'settings');
  }, [db]);
  const { data: config } = useDoc(configRef);

  const handleBootstrapAdmin = async (uid: string, user: string) => {
    if (!db) return;
    try {
      const roleRef = doc(db, 'roles_admin', uid);
      await setDoc(roleRef, { 
        role: 'admin',
        username: user,
        activated: true,
        updatedAt: serverTimestamp()
      }, { merge: true });
      
      toast({
        title: "تم تفعيل الدخول",
        description: "مرحباً بك في نظام كلاسك فون الملكي.",
      });
      
      router.push('/admin');
    } catch (e: any) {
      console.error('Bootstrap Error:', e);
      // حتى لو فشل حفظ الدور في Firestore بسبب القواعد مؤقتاً، سنحاول توجيهه
      router.push('/admin');
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth || !db) return;
    
    const cleanUser = username.trim().toLowerCase();
    if (!cleanUser || !password) return;
    
    setLoading(true);

    const email = `${cleanUser}@classic-mobile.com`;
    
    const defaultUser = 'ahmed_1990st';
    const defaultPass = 'xasdqwer4';
    
    const targetUser = config?.customUsername || defaultUser;
    const isTargetAdmin = cleanUser === targetUser;

    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      
      if (isTargetAdmin) {
        await handleBootstrapAdmin(userCredential.user.uid, cleanUser);
      } else {
        router.push('/admin');
      }
    } catch (error: any) {
      // التعامل مع حالة تسجيل المسؤول لأول مرة
      if (isTargetAdmin && (error.code === 'auth/user-not-found' || error.code === 'auth/invalid-credential' || error.code === 'auth/invalid-login-credentials')) {
        if (cleanUser === defaultUser && password === defaultPass) {
          try {
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            await handleBootstrapAdmin(userCredential.user.uid, cleanUser);
          } catch (setupError: any) {
             console.error('Setup Error:', setupError);
             toast({ variant: "destructive", title: "خطأ في التفعيل", description: "تأكد من تفعيل Email/Password في Firebase." });
          }
        } else {
          toast({ variant: "destructive", title: "بيانات خاطئة", description: "يرجى التأكد من اسم المستخدم وكلمة المرور." });
        }
      } else {
        console.error('Login Error:', error);
        toast({ variant: "destructive", title: "فشل الدخول", description: "يرجى التأكد من اتصال الإنترنت وصحة البيانات." });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,rgba(191,155,48,0.05),transparent)] pointer-events-none" />
      
      <div className="w-full max-w-md space-y-4">
        <Button 
          variant="ghost" 
          className="text-primary mb-2 hover:bg-primary/10 group"
          onClick={() => router.push('/')}
        >
          <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          العودة للموقع
        </Button>

        <Card className="border-primary/20 shadow-2xl bg-secondary/20 backdrop-blur-md relative z-10 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
          <CardHeader className="text-center space-y-4">
            <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center mx-auto shadow-[0_0_20px_rgba(191,155,48,0.3)]">
              <Smartphone className="text-background w-10 h-10" />
            </div>
            <CardTitle className="font-headline text-3xl text-primary font-bold">نظام الإدارة</CardTitle>
            <CardDescription>
              {config?.isConfigured ? "أدخل بيانات المسؤول المخصصة" : "أدخل البيانات الافتراضية للتحكم بالمركز"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <div className="relative">
                  <User className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
                  <Input
                    placeholder="اسم المستخدم"
                    className="pr-10 bg-background/50 border-primary/20 focus:border-primary text-right"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <div className="relative">
                  <Lock className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
                  <Input
                    type="password"
                    placeholder="كلمة المرور"
                    className="pr-10 bg-background/50 border-primary/20 focus:border-primary text-right"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>
              </div>
              <Button 
                type="submit" 
                className="w-full h-12 bg-primary hover:bg-primary/90 text-background font-bold text-lg shadow-lg"
                disabled={loading}
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <div className="flex items-center gap-2"><Sparkles className="w-5 h-5" /> دخول النظام الملكي</div>}
              </Button>
              
              {config?.isConfigured && (
                <div className="flex items-center gap-2 justify-center text-[10px] text-muted-foreground bg-primary/5 p-2 rounded-lg">
                  <ShieldAlert className="w-3 h-3 text-primary/70" />
                  <span>نظام الأمان المخصص قيد التشغيل حالياً</span>
                </div>
              )}
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}